﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc4events.Models
{
    public class Event
    {
        public string Title { get; set; }
        public string Technology { get; set; }
        public string Date { get; set; }
        public string URL { get; set; }
    }
}